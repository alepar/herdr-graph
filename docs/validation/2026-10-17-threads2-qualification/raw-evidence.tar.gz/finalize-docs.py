from pathlib import Path
import json,re,shlex,shutil
r=Path(__file__).parent
repo=Path('/Users/alepar/AleCode/herdr-graph')
head='d9a50590c6ca3dccc558664d4ed608eb2153605d'
commands=json.loads((r/'command-results.json').read_text())
assert len(commands)==7 and all(x['exit_code']==0 for x in commands)
matrix=json.loads((r/'matrix.json').read_text())
assert matrix['head']==head and matrix['status']=='PASS'
assert len(matrix['releases'])==5
for row in matrix['releases']:
 assert row['status']=='PASS'
 assert sum(s['observed_count'] for s in row['suites'].values())==37
 assert all(s['status']=='PASS' and s['cleanup']['clean'] and not s['cleanup']['reaped'] and not s['cleanup']['survivors'] for s in row['suites'].values())
counts={}
for c in commands:
 text=Path(c['log']).read_text()
 groups=[tuple(map(int,m)) for m in re.findall(r'test result: ok[.] (\d+) passed; (\d+) failed; (\d+) ignored;',text)]
 counts[c['name']]=tuple(sum(x[i] for x in groups) for i in range(3))
assert counts['default']==(694,0,1) and counts['no-default']==(691,0,1) and counts['test-support']==(710,0,1) and counts['config-isolation']==(16,0,0)
order=['all-consumers','default','no-default','test-support','config-isolation','driver-tests','matrix']
by_name={x['name']:x for x in commands}
lines=['| Exact command | Source HEAD | Result | Exit | Seconds |','|---|---|---|---:|---:|']
for n in order:
 c=by_name[n]
 if n in ['default','no-default','test-support','config-isolation']:
  p,f,i=counts[n]; result=f'{p} passed, {f} failed, {i} ignored'
 elif n=='driver-tests': result='24 passed, 0 failed/errors/skips'
 elif n=='matrix': result='185 passed; all 15 cleanup gates clean'
 else: result='all consumers compiled'
 prefix='HG_REAL_AGENTS=0 ' if n=='config-isolation' else ''
 lines.append(f"| `{prefix}{shlex.join(c['command'])}` | `{c['graph_head'][:7]}` | {result} | 0 | {c['seconds']:.3f} |")
command_table='\n'.join(lines)
lines=['| Herdr actual version | Graph | API | Threads | Cleanup | Official macOS aarch64 SHA-256 |','|---|---:|---:|---:|---|---|']
for row in matrix['releases']:
 lines.append(f"| `herdr {row['version']}` | 30/30 | 5/5 | 2/2 | clean, 0 reaped/survivors | `{row['sha256']}` |")
matrix_table='\n'.join(lines)
ledger=repo/'.superpowers/sdd/2026-10-17-threads2-herdr-matrix/progress.md'
rulings=[line for line in ledger.read_text().splitlines() if line.startswith('Ruling:')]
assert len(rulings)>=7
handoff=(r/'handoff-template.md').read_text().replace('{{COMMAND_TABLE}}',command_table).replace('{{MATRIX_TABLE}}',matrix_table).replace('{{RULINGS}}','\n\n'.join(rulings))
assert '{{' not in handoff
handoff_path=repo/'docs/releases/2026-10-17-threads2-herdr-qualification.md'
handoff_path.write_text(handoff)
(r/'controller-rulings.txt').write_text('\n'.join(rulings)+'\n')
readme=repo/'README.md';text=readme.read_text()
old='[docs/verification-matrix.md](docs/verification-matrix.md) records the October 7 integration and dated historical evidence (private Herdr 0.9.1, macOS aarch64). The [release handoff](docs/releases/2026-10-07-agreed-fixes-handoff.md) contains the current sequential validation counts and compatibility limits.'
new='[docs/verification-matrix.md](docs/verification-matrix.md) records the October 17 exact threads 2.0.3 qualification on macOS aarch64: Herdr **0.9.1–0.9.5 each passed all 37 private graph/API/threads cases** (185 total), with clean teardown. The [qualification handoff](docs/releases/2026-10-17-threads2-herdr-qualification.md) records exact source revisions, feature-suite counts, checksums, preserved failures, recovery limits and review/integration gates. October 5/7 evidence remains historical and unchanged.'
assert old in text;readme.write_text(text.replace(old,new))
p=repo/'CURRENT-DESIGN.md';text=p.read_text().replace('current exact-tag/runtime evidence is recorded in the qualification handoff when complete.','current exact-tag/runtime evidence is recorded in [the qualification handoff](docs/releases/2026-10-17-threads2-herdr-qualification.md).');p.write_text(text)
p=repo/'docs/verification-matrix.md';text=p.read_text();at=text.index('## Agreed fixes and herdr-threads 0.2.9')
section=f'''## Threads 2.0.3 qualification (2026-10-17)

Current source qualification uses graph `{head}`, official threads v2.0.3 commit `ded34fa971c18cef81ea1b597097a8ff7cd91eb3`, protocol **9**, and macOS aarch64. The dependency is an exact-release Git submodule; no moving external source checkout is used. Final docs add no executable-source changes. Older dated evidence below remains historical.

| Check | Result |
|---|---|
| all-consumer locked/offline check | pass, exit 0 |
| default | 694 passed, 0 failed, 1 explicit packaging-build ignored |
| no-default | 691 passed, 0 failed, 1 explicit packaging-build ignored |
| test-support, ordinary parallel harness | 710 passed, 0 failed, 1 explicit packaging-build ignored |
| remaining private config/isolation | 16 harness passes: 12 isolation, shell, summary printer, 2 native early returns |
| driver behavioral regressions | 24 passed, 0 errors/skips |
| Herdr 0.9.1 / 0.9.2 / 0.9.3 / 0.9.4 / 0.9.5 | each 30 graph + 5 API + 2 actual threads = 37 passed; 185 total |
| matrix cleanup | all 15 gates clean; 190 owned roots removed; no emergency reaping/survivors |
| fmt / whitespace | pass |

Default/no-default ran at `33be69e`; the controller retained those unaffected passes after the narrowly gated `cfg(test,test-support)` subprocess-fixture fix in `d9a5059`. Final all-consumer/test-support/matrix checks cover that final source. The first default and parallel test-support failures remain FAIL in the evidence; the fixes and red/green checks are documented, without relaxing any matrix gate.

Native agents were disabled (`HG_REAL_AGENTS=0`): Claude/Codex config early returns are not launch/resume evidence. The 37-case matrix has no skipped/ignored/filtered cases and does not repeat those native opt-ins. It uses shells, synthetic hooks/transcripts and cooperative CLI acceptance/ACK, with summary completion played through the CLI. Real native bootstrap/root-agent/summarizer inference, credentials, remote continuity, actual restore holds and live-session handoff remain unverified. Restore/epoch fake and hybrid evidence is not relabeled as real remote behavior.

See [the exact commands, per-version checksums, migration limits and rulings](releases/2026-10-17-threads2-herdr-qualification.md), [the 37-case contract](validation/herdr-release-matrix.md), and [the durable evidence bundle](validation/2026-10-17-threads2-qualification/README.md). Graph rebuild/operator restart is required to load protocol-9 code; no source plugin binary was replaced and no live restart was performed. Independent Task 4/whole-branch review and integration remain controller gates.

'''
p.write_text(text[:at]+section+text[at:])
p=repo/'docs/validation/herdr-release-matrix.md';text=p.read_text();at=text.index('## Qualification status')
p.write_text(text[:at]+f'''## Qualification status — 2026-10-17

The complete **0.9.1–0.9.5** matrix passed on **macOS aarch64** at graph `{head}` with the initialized official threads v2.0.3 submodule `ded34fa971c18cef81ea1b597097a8ff7cd91eb3`, protocol 9. Each version passed all **30 graph + 5 API + 2 actual threads = 37 cases**: **185 total**. All 15 suite cleanup gates were clean, all 190 owned roots were removed, and no emergency reaping, survivors, ignored/filtered/skipped cases, panic diagnostics, timeouts or cancellations occurred. Actual reported binary versions and SHA-256 values matched the official pins.

[The integration handoff](../releases/2026-10-17-threads2-herdr-qualification.md) records exact commands, source distinctions, checksums, preserved failed trials, native exclusions and migration limits. [The evidence bundle](2026-10-17-threads2-qualification/README.md) retains all case/cleanup observations and raw logs. `--check-upstream` passed against the five official stable releases and all 20 platform digests. Runtime support is limited to this tested macOS architecture; Linux/Intel digests alone do not imply qualification.

Historical Task 3 evidence qualified only 0.9.5 against the clean post-tag external checkout. Its failed/cancelled trials and [implementation report](../superpowers/reviews/2026-10-17-threads2-task-3-implementation.md) remain preserved. The final exact-tag sweep above supersedes its pending full-matrix status. Task 4's independent review and whole-branch integration remain controller work; this is not a merge or publication claim.
''')
report=f'''# Task 4 implementation report

Implementation base: `c1b3af1963bc04734f11686cf8c27d1f27edc89a`, branch `threads2-herdr-matrix`. Final frozen runtime source: `{head}`. Threads dependency: exact official v2.0.3 commit `ded34fa971c18cef81ea1b597097a8ff7cd91eb3`, wire protocol9. Platform: macOS aarch64. This report is an implementation/qualification handoff for fresh independent review, not integration or release approval.

## Changes and reviewed boundaries

- `456dd9c`: replace moving absolute dependency symlink with an official-URL Git submodule at exact v2.0.3; root Cargo.lock unchanged. The external checkout advanced to clean unreleased `b83d032a64cb9f665f49806b744f7cc730626819`; the old symlink reproduced a locked-metadata failure. The external checkout was never edited. Controller reviewed/approved the pin before qualification resumed.
- `33be69e`: the existing packaging README contract still required `ln -sfn`; replace only that obsolete assertion with `git submodule update --init --recursive`. Preserve every other packaging check. Focused test green1/0; full default rerun green694/0/1. The failed original default693/1/1 remains FAIL, exit101.
- `d9a5059`: fix the newly exposed parallel test-support race without changing production semantics or the failpoint API. The reconnect CAS crash fixture armed global writer failpoints in the shared library process; three sibling writer tests panicked. Reuse existing TestRoot through narrowly cfg(test,test-support)-gated self-alias/imports, spawn the exact current-test case in a private scrubbed process/TMPDIR with bounded ChildGuard cleanup, and retain the complete original commit/journal/binding/crash recovery body. Verify exactly one selected successful child case/summary. The new sentinel regression itself always runs in a dedicated child and proves the crash fixture leaves its parent's failpoint registry intact.
- Final docs update README, current design, graph state layout, verification/matrix status and [integration handoff](../../releases/2026-10-17-threads2-herdr-qualification.md). The handoff copies all {len(rulings)} current ledger Ruling lines verbatim, gives exact reconnect/rebuild/restart commands, old-plan/undo/external participation limits, checksum provenance and new-upstream detection workflow.
- Copy Task1 review, Task2 review/rereview1 and Task3 review/rereview1 byte-identically into proper docs; existing implementation reports remain unchanged. Task4's ignored workspace report and this proper report are synchronized. No scratch workspace is force-added.

## Failure diagnosis and red/green evidence

All logs remain under `{r}/logs/` and in the durable raw evidence archive. No failed run is relabeled or deleted.

- Pre-pin all-consumer build deliberately interrupted before runtime when controller required a committed immutable dependency pin; exact owned runner/build quiescence checked. Retained prepin-all-consumers-cancelled.log/prepin-interruption.json.
- Moving-dependency metadata red: locked/offline metadata exit101 because unreleased external package requires lock update. Pinned host-filtered metadata green exit0 resolves2.0.3. The unrestricted metadata attempt separately hit uncached Android package `android_system_properties v0.1.6` under offline mode, exit101; it is not a green result despite the early log filename. Correct official Herdr metadata replaced an initial wrong-repository404 lookup; all outcomes documented in trial-notes.md.
- Packaging red: pin456-default-failed.log,693passed/1failed/1ignored exit101. Green: packaging-submodule-green.log,1passed; final default.log,694passed/0failed/1ignored exit0.
- Parallel test-support red: test-support-parallel-failed.log,706passed/3failed/1ignored exit101. Source inspection identified the process-global failpoint registry. Serial focused plan group72/0 was diagnosis only, never qualification.
- Deterministic isolation red: crash-isolation-red.log, sentinel child catches original inline fixture hitting its parent's CAS failpoint, exit101. First green attempt failed because its helper demanded zero filtered siblings under --exact; that trial remains crash-isolation-first-green-attempt-failed.log. Corrected helper requires one selected pass and one successful summary while allowing intentionally filtered sibling cases; the matrix's no-filter gate is unchanged.
- Focused parallel green: `cargo test --locked --offline --features test-support --lib reconnect_ -- --test-threads=8`,16passed/0failed, exit0,6.02s, crash-isolation-green.log. Final ordinary parallel full test-support covers the committed fix. No broad serial substitute, production behavior change, source scanner allowlist expansion or matrix gate relaxation occurred.

## Final sequential checks

{command_table}

Default/no-default evidence is at33be69e, retained by controller because the final delta is narrowly cfg(test,test-support). Final all-consumer, ordinary parallel test-support, config/isolation, driver and matrix use d9a5059. Each feature build/test command is locked/offline and Cargo invocations were sequential. Matrix builds graph executables/bin once, then actual threads once before dispatch. Fmt and whitespace checks pass. The ignored release-build packaging test is intentionally unrun; runtime plugin startup/actions use a private package and prebuilt graph binary.

Config/isolation16 is a harness count:12 isolation cases, shell/summary checks, plus two explicit disabled native Claude/Codex early returns. ConfigJSON says shell VERIFIED and both native configs SKIPPED, with HG_REAL_AGENTS=0. No actual native bootstrap/launch/resume/root-agent/summarizer flow was qualified. Driver24 contains negative tests for strict failure/cleanup gates; matrix has no skips/ignored/filtered cases. No redundant standalone37-case private sweep was run.

## Runtime matrix and provenance

{matrix_table}

Total185 runtime cases; all15 suite gates clean,190 owned roots removed,0 emergency reaped/0 survivors, no timeouts/cancellation/panic diagnostics. Official metadata still identifies latest stable threads2.0.3 and Herdr0.9.5; peeled tagded34fa9 is recorded. The --check-upstream maintenance gate exits0 for all five versions/all20 pinned digests. Linux/Intel checksums are provenance only; actual runtime qualification is macOS aarch64.

Private graph clone `{r}/graph` is clean/detached at d9a5059; nested submodule clean/detached at exactded. The initial pin456 source comparison proved all427 tracked entries byte-equal. Later frozen-source/final comparisons allow only concurrent Markdown changes and assert all executable source/tests/scripts/manifests/lock/gitlink bytes equal. [The evidence bundle](../../validation/2026-10-17-threads2-qualification/README.md) includes exact source/binary hashes, command heads/counts/exits, all per-case/cleanup identity evidence, official provenance and raw final/failed/build logs. Private clones/cache remain retained for review.

## Preservation, recovery and limits

Root source bin/herdr-graph remains the original Oct7 artifact,13624672 bytes, SHA256 bbc9a7bf8de817cb3dcccfae2e5300de5cb7daac8700b40622ddc64c5971621c, unchanged mtime/size. The clone has no source bin artifact. External threads checkout stays clean/unchanged. No user daemon, live session, native credential store, upstream source, peer link or read-only release cache was modified. No push/merge/version bump/install/release/archive publication occurred.

The handoff documents commit-first node/epoch markers, preserved mutations/threads-reconnect artifacts, per-epoch journals and old-journal seals; explicit from/to/head-fenced plan/apply; mandatory pre-boundary re-planning; undo refusal; preserving native/completed history and explicit external participation reassessment. Build setup initializes submodules; buildable source archives must include pinned dependency contents. Protocol9 requires graph rebuild/operator restart, neither installed nor performed on the live system here.

Shell/synthetic fixtures cover actual local private Herdr/threads, cooperative public-hook enrollment/CLI acceptance/read/exact ACK, and reviewed graph recovery. Native inference/auth/bootstrap/root-agent/summarizer quality, remote continuity, actual restore-induced holds and live-session handoff remain excluded. Fake/hybrid restore/epoch/race evidence is named separately. Guarded cleanup is not a kernel-containment claim.

Self-review checked each Task4 brief/preflight requirement, exact source/command provenance, unchanged production semantics, strict gates, review-copy equality, preserved failed evidence and all current controller rulings. Task4 independent review and whole-branch review/integration remain required controller work.
'''
proper=repo/'docs/superpowers/reviews/2026-10-17-threads2-task-4-implementation.md';proper.write_text(report)
(repo/'.superpowers/sdd/2026-10-17-threads2-herdr-matrix/task-4-report.md').write_text(report)
assert proper.read_bytes()==(repo/'.superpowers/sdd/2026-10-17-threads2-herdr-matrix/task-4-report.md').read_bytes()
print('Wrote final docs/report; exact ledger rulings:',len(rulings))
