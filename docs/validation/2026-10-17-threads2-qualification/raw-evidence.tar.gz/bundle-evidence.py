from pathlib import Path
import hashlib,json,tarfile,shutil
r=Path(__file__).parent
repo=Path('/Users/alepar/AleCode/herdr-graph')
b=repo/'docs/validation/2026-10-17-threads2-qualification'
b.mkdir(exist_ok=False)
shutil.copyfile(r/'graph/target/hg-config-smoke.json',r/'config-smoke.json')
# Keep public machine evidence readable; every raw final/failed log is archived byte-for-byte.
public=['verified-evidence.json','command-results.json','matrix.json','matrix.md','official-provenance.json','final-official-provenance.json','herdr-official-assets-preflight.json','herdr-releases-tested.tsv','threads-official-tag-remote.txt','pinned-source-equivalence.json','artifact-before.json','review-copies.json','config-smoke.json','controller-rulings.txt','trial-notes.md']
for name in public:shutil.copyfile(r/name,b/name)
raw=[]
for p in sorted((r/'logs').rglob('*')):
 if p.is_file() and not p.is_symlink():raw.append(p)
for p in sorted((r/'matrix.logs').rglob('*')):
 if p.is_file() and not p.is_symlink() and p.suffix in ('.log','.json','.jsonl'):raw.append(p)
for p in sorted(r.iterdir()):
 if p.is_file() and not p.is_symlink() and p.suffix in ('.json','.txt','.tsv','.py','.md') and p.name!='handoff-template.md':raw.append(p)
raw=sorted(set(raw))
manifest=[]
with tarfile.open(b/'raw-evidence.tar.gz','w:gz') as tar:
 for p in raw:
  name=str(p.relative_to(r));data=p.read_bytes();manifest.append({'path':name,'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest()});tar.add(p,arcname=name,recursive=False)
(b/'raw-evidence-manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
# Verify the archive without extracting it or changing the retained originals.
with tarfile.open(b/'raw-evidence.tar.gz','r:gz') as tar:
 assert tar.getnames()==[x['path'] for x in manifest]
 for item in manifest:
  data=tar.extractfile(item['path']).read();assert len(data)==item['bytes'] and hashlib.sha256(data).hexdigest()==item['sha256']
proof=json.loads((b/'verified-evidence.json').read_text())
assert proof['runtime_cases']==185 and proof['fixture_roots_removed']==190
readme=f'''# Exact threads 2.0.3 qualification evidence — 2026-10-17

Final runtime source: graph `{proof['graph_head']}`, initialized threads submodule `{proof['threads_head']}`, protocol9, macOS aarch64. Herdr0.9.1–0.9.5 each passed37 cases:185 total; all15 cleanup gates clean,190 owned roots removed, no emergency reaping/survivors. Task4/whole-branch review and integration remain controller gates.

- [Verified evidence](verified-evidence.json): actual binary versions/SHA256, all15 suite counts/times/cleanups, prebuilt graph/test/threads hashes, config statuses, and final source/artifact preservation assertions.
- [Commands](command-results.json): exact flags, execution heads, exits and durations. Default694/0/1 and no-default691/0/1 ran at33be69e; the final cfg(test,test-support)-only fix is covered by ordinary parallel test-support710/0/1 and all consumers atd9a5059. Native config16 harness passes include2 explicit early returns; driver24 passed.
- [Full matrix JSON](matrix.json) and [driver Markdown](matrix.md): every exact case/result and complete owned PID/start/cleanup data. Original absolute log paths are preserved; their contents are mirrored in the archive under the same relative matrix.logs paths.
- [Final official provenance](final-official-provenance.json), [initial official provenance](official-provenance.json), [official asset metadata](herdr-official-assets-preflight.json), [tested pins](herdr-releases-tested.tsv), [remote annotated/peeled tag](threads-official-tag-remote.txt).
- [Frozen source hashes](pinned-source-equivalence.json):427 tracked entries compared at final freeze, concurrent Markdown differences only. Verified evidence additionally proves all175 code/test/script/manifest/lock/gitlink entries equal after final docs changes. [Original local artifact](artifact-before.json) and final proof preserve its13624672-byte size, mtime and SHA256; external checkout stays clean/unchanged.
- [Config JSON](config-smoke.json): shell VERIFIED, Claude/Codex SKIPPED because HG_REAL_AGENTS=0. These are not native launch/resume passes.
- [Review copy hashes](review-copies.json) and [verbatim controller rulings](controller-rulings.txt).
- [Preserved trial notes](trial-notes.md): failed default/test-support, deterministic isolation red, intermediate exact-filter assertion failure, interrupted pre-pin check and offline/metadata setup attempts remain their actual outcomes.
- [Raw evidence archive](raw-evidence.tar.gz), [member hashes](raw-evidence-manifest.json):{len(manifest)} byte-identical members, including every Task4 final/failed/build log, per-suite roots/result/cleanup JSON, prior source/command snapshots, raw official metadata, and exact local workflow/verification scripts. No binaries, credentials, source Git databases or unrelated files are archived.

The full retained clone/cache/log root is `{r}`. The archive was reopened and each member's SHA256/length checked against its original bytes. Verify the checked-in bundle with:

```sh
shasum -a 256 -c SHA256SUMS
```

Raw archive member names are relative. Inspect or extract it only into an empty private directory. Historical Task3 trial logs remain at their original documented locations; October5/7 evidence and prior proper reports are unchanged. [The integration handoff](../../releases/2026-10-17-threads2-herdr-qualification.md) records exact commands, recovery/rebuild/restart requirements, limits and all rulings. Shell/synthetic fixtures do not qualify native inference/auth/bootstrap/root-agent/summarizer flows, remote continuity, actual restore holds, Linux/Intel runtime, or a live user-session handoff. No live services were restarted, plugin binary replaced, version bumped, branch merged or pushed, or release published.
'''
(b/'README.md').write_text(readme)
lines=[]
for p in sorted(b.iterdir()):
 if p.is_file():lines.append(f'{hashlib.sha256(p.read_bytes()).hexdigest()}  {p.name}')
(b/'SHA256SUMS').write_text('\n'.join(lines)+'\n')
print('Evidence bundle',b,'raw members',len(manifest),'archive bytes',(b/'raw-evidence.tar.gz').stat().st_size)
