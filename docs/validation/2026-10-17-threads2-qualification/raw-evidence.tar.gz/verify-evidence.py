from pathlib import Path
import subprocess,json,hashlib,re,platform
root=Path(__file__).parent
source=Path('/Users/alepar/AleCode/herdr-graph')
graph=root/'graph'
commands=json.loads((root/'command-results.json').read_text())
assert len(commands)==7 and all(c['exit_code']==0 for c in commands)
counts={}
for row in commands:
 text=Path(row['log']).read_text()
 summaries=[tuple(map(int,m)) for m in re.findall(r'test result: ok[.] (\d+) passed; (\d+) failed; (\d+) ignored; (\d+) measured; (\d+) filtered out;',text)]
 counts[row['name']]={'summaries':summaries,'passed':sum(x[0] for x in summaries),'failed':sum(x[1] for x in summaries),'ignored':sum(x[2] for x in summaries),'skip_diagnostics':len(re.findall(r'SKIPPED:',text))}
 if row['name'] in ('default','no-default','test-support','config-isolation'): assert summaries and all(x[1]==0 and x[3]==0 and x[4]==0 for x in summaries)
 if row['name']=='driver-tests': assert re.search(r'Ran 24 tests in ',text) and text.rstrip().endswith('OK')
assert counts['config-isolation']['skip_diagnostics']==2
assert counts['config-isolation']['passed']==16
config_matrix=json.loads((graph/'target/hg-config-smoke.json').read_text())
assert {r['config']:r['status'] for r in config_matrix}=={'claude':'SKIPPED','codex':'SKIPPED','shell':'VERIFIED'}
matrix=json.loads((root/'matrix.json').read_text())
head=subprocess.check_output(['git','-C',str(graph),'rev-parse','HEAD'],text=True).strip()
assert matrix['head']==head=='d9a50590c6ca3dccc558664d4ed608eb2153605d'
assert matrix['status']=='PASS' and matrix['expected_cases_per_release']==37 and matrix['native_models'] is False
assert Path(matrix['threads_source']).resolve()==(graph/'third_party/herdr-threads').resolve()
assert [r['version'] for r in matrix['releases']]==['0.9.1','0.9.2','0.9.3','0.9.4','0.9.5']
versions=[]; total=0; fixtures=0
for row in matrix['releases']:
 assert row['status']=='PASS'
 binary=Path(row['binary']); actual=subprocess.run([str(binary),'--version'],capture_output=True,text=True,timeout=10)
 assert actual.returncode==0 and actual.stdout.strip()=='herdr '+row['version']
 digest=hashlib.sha256(binary.read_bytes()).hexdigest(); assert digest==row['sha256']
 suites={}
 for name,suite in row['suites'].items():
  expected={'e2e_private_herdr':30,'herdr_client':5,'threads_real':2}[name]; roots={'e2e_private_herdr':30,'herdr_client':5,'threads_real':3}[name]
  assert suite['status']=='PASS' and suite['returncode']==0 and not suite['timed_out'] and not suite['cancelled']
  assert suite['observed_count']==expected and len(suite['cases'])==expected and set(suite['cases'].values())=={'PASS'}
  cleanup=suite['cleanup']; assert cleanup['clean'] and not cleanup['errors'] and not cleanup['reaped'] and not cleanup['survivors'] and not cleanup['leaked'] and len(cleanup['roots'])==roots
  assert all(not Path(r).exists() for r in cleanup['roots'])
  suites[name]={'passed':expected,'seconds':suite['seconds'],'roots':roots,'cleanup_clean':True,'emergency_reaped':0,'survivors':0}
  total+=expected;fixtures+=roots
 versions.append({'version':row['version'],'actual_version':actual.stdout.strip(),'actual_version_exit_code':actual.returncode,'asset':row['asset'],'sha256':digest,'suites':suites})
assert total==185 and fixtures==190
# Final graph source/build/test contract is identical; final edits are documentation only.
changed=[]; checked=[]
for f in subprocess.check_output(['git','-C',str(graph),'ls-files','-z'],text=True).split('\0'):
 if not f:continue
 if f=='third_party/herdr-threads':
  a=subprocess.check_output(['git','-C',str(graph/f),'rev-parse','HEAD'],text=True).strip(); b=subprocess.check_output(['git','-C',str(source/f),'rev-parse','HEAD'],text=True).strip(); equal=a==b=='ded34fa971c18cef81ea1b597097a8ff7cd91eb3'
 else: equal=(graph/f).read_bytes()==(source/f).read_bytes()
 if not equal:changed.append(f)
 if f.startswith(('src/','tests/','scripts/')) or f in ('Cargo.toml','Cargo.lock','.gitmodules','third_party/herdr-threads','herdr-plugin.toml'): checked.append(f); assert equal,f
assert all(f.endswith('.md') for f in changed)
assert not subprocess.check_output(['git','-C',str(graph),'status','--short'],text=True).strip()
assert not subprocess.check_output(['git','-C',str(graph/'third_party/herdr-threads'),'status','--short'],text=True).strip()
prior=json.loads((root/'artifact-before.json').read_text()); f=source/'bin/herdr-graph'; stat=f.stat(); assert stat.st_size==prior['size'] and stat.st_mtime_ns==prior['mtime_ns'] and hashlib.sha256(f.read_bytes()).hexdigest()==prior['sha256']
external=Path('/Users/alepar/AleCode/herdr-threads'); external_head=subprocess.check_output(['git','-C',str(external),'rev-parse','HEAD'],text=True).strip(); external_status=subprocess.check_output(['git','-C',str(external),'status','--short'],text=True).strip()
assert external_head==prior['external_head_at_start'] and not external_status
assert not (graph/'bin/herdr-graph').exists()
prebuilt={}
for line in (root/'matrix.logs/build/graph-build.log').read_text().splitlines():
 try: message=json.loads(line)
 except ValueError: continue
 name=message.get('target',{}).get('name')
 if message.get('reason')=='compiler-artifact' and name in ('e2e_private_herdr','herdr_client','threads_real') and message.get('executable') and message.get('profile',{}).get('test'):
  binary=Path(message['executable']);prebuilt[name]={'path':str(binary),'sha256':hashlib.sha256(binary.read_bytes()).hexdigest()}
for name,binary in [('graph',graph/'target/debug/herdr-graph'),('threads',graph/'target/threads-bin/debug/herdr-threads')]:
 prebuilt[name]={'path':str(binary),'sha256':hashlib.sha256(binary.read_bytes()).hexdigest()}
assert len(prebuilt)==5
payload={'config_matrix':config_matrix,'prebuilt_executables':prebuilt,'graph_head':head,'threads_head':'ded34fa971c18cef81ea1b597097a8ff7cd91eb3','protocol':9,'platform':platform.platform(),'commands':counts,'versions':versions,'runtime_cases':total,'fixture_roots_removed':fixtures,'code_build_test_entries_equal':len(checked),'original_tracked_docs_changed':changed,'root_bin_unchanged':True,'external_checkout_unchanged_clean':True}
(root/'verified-evidence.json').write_text(json.dumps(payload,indent=2)+'\n')
print(json.dumps(payload,indent=2))
