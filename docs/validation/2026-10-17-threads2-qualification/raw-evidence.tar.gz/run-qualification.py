import subprocess,os,json,time
from pathlib import Path
root=Path(__file__).parent
graph=root/'graph'
env=os.environ.copy()
for key in list(env):
 if key.startswith(('ANTHROPIC_','OPENAI_','HERDR_','CLAUDE_')): env.pop(key)
env['HG_REAL_AGENTS']='0'
env['HG_TEST_HERDR_BINARY']='/private/tmp/hg-task3-herdr-cache/0.9.5/macos-aarch64/herdr'
env['PYTHONDONTWRITEBYTECODE']='1'
commands=[
 ('all-consumers',['cargo','check','--locked','--offline','--all-targets','--all-features']),
 ('default',['cargo','test','--locked','--offline','--no-fail-fast']),
 ('no-default',['cargo','test','--locked','--offline','--no-default-features','--no-fail-fast']),
 ('test-support',['cargo','test','--locked','--offline','--features','test-support','--no-fail-fast']),
 ('config-isolation',['cargo','test','--locked','--offline','--features','private-herdr','--test','config_smoke','--test','test_isolation','--','--test-threads=1','--nocapture']),
 ('driver-tests',['python3','-m','unittest','discover','-s','scripts/tests','-v']),
 ('matrix',['scripts/herdr-release-smoke','--versions','0.9.1','0.9.2','0.9.3','0.9.4','0.9.5','--jobs','2','--cache',str(root/'herdr-cache'),'--report',str(root/'matrix')]),
]
from shlex import join as shlex_join
results=json.loads((root/'command-results.json').read_text())
commands=[c for c in commands if c[0] not in ('default','no-default')]
for name,command in commands:
 started=time.time(); log=root/'logs'/f'{name}.log'
 print('START',name,shlex_join(command),flush=True)
 with log.open('w') as out: result=subprocess.run(command,cwd=graph,env=env,stdout=out,stderr=subprocess.STDOUT)
 row={'graph_head':subprocess.check_output(['git','rev-parse','HEAD'],cwd=graph,text=True).strip(),'name':name,'command':command,'exit_code':result.returncode,'seconds':round(time.time()-started,3),'log':str(log)}
 results.append(row); (root/'command-results.json').write_text(json.dumps(results,indent=2)+'\n')
 print('END',name,'exit',result.returncode,'seconds',row['seconds'],'log',log,flush=True)
 if result.returncode: raise SystemExit(result.returncode)

