from pathlib import Path
import json,hashlib,subprocess,tarfile,sys,os,shutil
sys.dont_write_bytecode=True
root=Path(__file__).parent;repo=Path('/Users/alepar/AleCode/herdr-graph');graph=root/'graph'
bundle=repo/'docs/validation/2026-10-18-threads2-log-qualification';bundle.mkdir(exist_ok=True)
def digest(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def git(path,*args):return subprocess.check_output(['git','-C',str(path),*args],text=True).strip()
commands=json.loads((root/'command-results.json').read_text());assert len(commands)==6 and all(c['exit_code']==0 for c in commands)
matrix=json.loads((root/'matrix.json').read_text());assert matrix['status']=='PASS' and len(matrix['releases'])==5
source=json.loads((root/'frozen-source.json').read_text())
assert git(graph,'rev-parse','HEAD')==source['head']
assert git(graph/'third_party/herdr-threads','rev-parse','HEAD')==source['threads_head']
for base,items in [(graph,source['graph']),(graph/'third_party/herdr-threads',source['threads'])]:
 for name,item in items.items():
  if item['mode']!='160000':assert digest(base/name)==item['sha256'],name
code={name:item for name,item in source['graph'].items() if name.startswith(('src/','tests/','scripts/')) or name in ('Cargo.toml','Cargo.lock','.gitmodules','herdr-plugin.toml','third_party/herdr-threads')}
for name,item in code.items():
 if item['mode']=='160000':assert git(repo/name,'rev-parse','HEAD')==source['threads_head']
 else:assert digest(repo/name)==item['sha256'],name
results=[];log_count=0;log_bytes=0;roots=0;cases=0
for row in matrix['releases']:
 binary=Path(row['binary']);version=subprocess.check_output([str(binary),'--version'],env={'PATH':'/usr/bin:/bin'},text=True).strip()
 assert version=='herdr '+row['version'] and digest(binary)==row['sha256']
 for name,s in row['suites'].items():
  assert s['status']=='PASS' and s['returncode']==0 and not s['timed_out'] and not s['cancelled']
  assert s['cleanup']['clean'] and not s['cleanup']['reaped'] and not s['cleanup']['survivors'] and not s['cleanup']['leaked']
  assert s['diagnostics']['clean'] and not s['diagnostics']['errors']
  assert len(s['cases'])==len(s['expected']) and set(s['cases'])==set(s['expected']) and set(s['cases'].values())=={'PASS'}
  roots+=len(s['cleanup']['roots']);cases+=len(s['cases'])
  for path in s['cleanup']['roots']:assert not Path(path).exists()
  for log in s['diagnostics']['files']:
   p=Path(log['archive']);assert digest(p)==log['sha256'] and p.stat().st_size==log['bytes'] and not log['panic']
   log_count+=1;log_bytes+=log['bytes']
 results.append({'version':row['version'],'actual_version':version,'sha256':digest(binary),'suites':row['suites']})
assert roots==190 and cases==185
pre=json.loads((root/'preflight.json').read_text());artifact=repo/'bin/herdr-graph';st=artifact.stat()
assert {'sha256':digest(artifact),'bytes':st.st_size,'mtime_ns':st.st_mtime_ns}==pre['artifact']
original=json.loads(Path('/private/tmp/hg-task4-qualification-534cd4f_/artifact-before.json').read_text())
assert pre['artifact']=={'sha256':original['sha256'],'bytes':original['size'],'mtime_ns':original['mtime_ns']}
assert original['sha256']=='bbc9a7bf8de817cb3dcccfae2e5300de5cb7daac8700b40622ddc64c5971621c'
external=Path('/Users/alepar/AleCode/herdr-threads');assert git(external,'rev-parse','HEAD')==pre['external_head'];assert git(external,'status','--porcelain')==pre['external_status']==''
for name,sha in json.loads((root/'historical-evidence-before.json').read_text()).items():assert digest(repo/name)==sha,name
oldgraph=Path('/private/tmp/hg-task4-qualification-534cd4f_/graph')
assert git(oldgraph,'rev-parse','HEAD')=='d9a50590c6ca3dccc558664d4ed608eb2153605d'
assert git(oldgraph,'status','--porcelain')==''
oldthreads=oldgraph/'third_party/herdr-threads';assert git(oldthreads,'rev-parse','HEAD')=='ded34fa971c18cef81ea1b597097a8ff7cd91eb3';assert git(oldthreads,'status','--porcelain')==''
executables=[graph/'target/debug/herdr-graph',graph/'target/threads-bin/debug/herdr-threads']
for line in (root/'matrix.logs/build/graph-build.log').read_text().splitlines():
 try:m=json.loads(line)
 except ValueError:continue
 if m.get('reason')=='compiler-artifact' and m.get('executable') and m.get('profile',{}).get('test'):
  executables.append(Path(m['executable']))
threads_version=subprocess.check_output([str(graph/'target/threads-bin/debug/herdr-threads'),'--version'],env={'PATH':'/usr/bin:/bin'},text=True).strip()
assert threads_version=='herdr-threads 2.0.4',threads_version
assert git(graph,'status','--porcelain')==''
assert git(graph/'third_party/herdr-threads','status','--porcelain')==''
verified={'actual_threads_version':threads_version,'source_head':source['head'],'threads_head':source['threads_head'],'threads_version':'2.0.4','wire_protocol':9,'platform':'macOS aarch64','cases':cases,'roots_removed':roots,'suite_cleanup_gates':15,'suite_diagnostic_gates':15,'diagnostic_files':log_count,'diagnostic_bytes':log_bytes,'source_inputs_equal':len(code),'executable_sha256':{str(p):digest(p) for p in executables},'artifact_preserved':pre['artifact'],'external_checkout_unchanged':True,'historical_bundle_and_source_unchanged':True,'releases':results,'exclusions':['native agents, inference, auth, bootstrap, root-agent and summarizer flows','remote continuity and actual restore-induced holds','Linux and Intel macOS runtime','live services and session handoff','broad feature results remain historical threads 2.0.3 evidence']}
(root/'verified-evidence.json').write_text(json.dumps(verified,indent=2)+'\n')
for name in ['matrix.json','matrix.md','command-results.json','verified-evidence.json','official-provenance.json','consumed-api-delta.json','threads-v2.0.4-tag-refs.txt','preflight.json','final-review-copy.json','controller-rulings.txt']:
 shutil.copyfile(root/name,bundle/name)
shutil.copyfile(graph/'tests/herdr-releases.tsv',bundle/'herdr-releases-tested.tsv')
# Exact original names/bytes beneath the retained qualification root.
files=[p for p in root.iterdir() if p.is_file()]
for directory in ['logs','matrix.logs','failure-regression']:
 files.extend(p for p in (root/directory).rglob('*') if p.is_file() and 'forbidden-tools' not in p.parts)
files=sorted(set(files));manifest={str(p.relative_to(root)):{'bytes':p.stat().st_size,'sha256':digest(p)} for p in files}
with tarfile.open(bundle/'raw-evidence.tar.gz','w:gz') as out:
 for p in files:out.add(p,arcname=str(p.relative_to(root)),recursive=False)
with tarfile.open(bundle/'raw-evidence.tar.gz','r:gz') as archived:
 assert len(archived.getmembers())==len(manifest)
 for m in archived.getmembers():
  raw=archived.extractfile(m).read();item=manifest[m.name]
  assert len(raw)==item['bytes'] and hashlib.sha256(raw).hexdigest()==item['sha256']
(bundle/'raw-evidence-manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
print(json.dumps({k:verified[k] for k in ['source_head','threads_head','cases','roots_removed','diagnostic_files','diagnostic_bytes','source_inputs_equal']},indent=2))
print('Verified raw archive members:',len(manifest))
