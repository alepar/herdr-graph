import importlib.machinery, importlib.util, os, json, uuid
from pathlib import Path
root=Path(__file__).parent
loader=importlib.machinery.SourceFileLoader('matrix',str(root/'graph/scripts/herdr-release-smoke'))
spec=importlib.util.spec_from_loader(loader.name,loader);m=importlib.util.module_from_spec(spec);loader.exec_module(m)
private=Path('/private/tmp/hg-'+uuid.uuid4().hex)
fixture=root/'child-log-panic-fixture'
fixture.write_text('''#!/usr/bin/env python3
import os,json
from pathlib import Path
root=Path(%r)
(root/'graph/.graph-local').mkdir(parents=True)
(root/'.matrix-owner').write_text(os.environ['HG_MATRIX_OWNER'])
(root/'herdr.log').write_text('clean server exit\\n')
(root/'graph/.graph-local/daemon.log').write_text("thread 'tokio-runtime-worker' panicked at fixture.rs:1:1:\\nchild-only sentinel\\n")
with open(os.environ['HG_MATRIX_REGISTRY'],'a') as out:out.write(json.dumps({'root':str(root)})+'\\n')
print('test core ... ok\\n\\ntest result: ok. 1 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out; finished in 0.01s')
''' % str(private));fixture.chmod(0o755)
r=m.run_suite(fixture,['core'],dict(os.environ),root/'failure-regression',5,1)
assert r['status']=='FAIL' and r['returncode']==0 and r['cleanup']['clean'] and private.exists(),r
(root/'failure-regression-root.txt').write_text(str(private)+'\n')
print(json.dumps({'status':r['status'],'cases':r['cases'],'cleanup_clean':r['cleanup']['clean'],'private_root':str(private),'diagnostic_errors':r['diagnostics']['errors']}))
