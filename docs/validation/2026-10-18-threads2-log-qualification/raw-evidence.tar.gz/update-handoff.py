from pathlib import Path
repo=Path('/Users/alepar/AleCode/herdr-graph');p=repo/'docs/releases/2026-10-17-threads2-herdr-qualification.md';s=p.read_text()
s=s.replace('# Threads 2.0.3 and recent Herdr qualification — 2026-10-17','# Threads 2.0.4 and recent Herdr replacement qualification — 2026-10-18')
a=s.index('This is an integration handoff');b=s.index('## Immutable source',a)
s=s[:a]+'''This is an integration handoff, not a new release. Current replacement qualification uses frozen graph `e621b44` with exact official herdr-threads **v2.0.4** commit `b83d032a64cb9f665f49806b744f7cc730626819`, wire protocol **9**, on **macOS aarch64**. The replacement checks private daemon/plugin diagnostics after cleanup and retains their raw bytes before removing successful fixture roots. The independent final review found that the earlier Task 4 gate checked harness output only; that original run and bundle remain unchanged historical evidence. Scoped final rereview and integration remain controller gates.

## Replacement source and latest-release decision

Driver/fixture commit `249067b` adds the bounded owned-log gate and private plugin stdout/stderr capture. Commit `e621b44` then changes only the threads gitlink and the graph lockfile's threads package version, 2.0.3 → 2.0.4. No graph production Rust changes occur in this fix wave. The new source clone is detached at that exact commit before runtime qualification, and the submodule is detached at `b83d032a64cb9f665f49806b744f7cc730626819`.

Official metadata refreshed at `2026-10-18T07:00:36Z` reported newly published v2.0.4 (`2026-10-18T06:56:10Z`); Herdr remained v0.9.5. Annotated threads tag `b869ebe878e1b947c1fb7fad054755dca0950f51` peels to `b83d032a64cb9f665f49806b744f7cc730626819`. The four-commit delta from v2.0.3 fixes child lifecycle execution identities and parent recovery, plus tests/publication/version metadata. Exact diffs under public protocol/service/node and daemon path/discovery modules are empty; protocol remains 9. The controller approved the newer stable target before pinning it. Sources: [official threads release](https://github.com/alepar/herdr-threads/releases/tag/v2.0.4), [official compare](https://github.com/alepar/herdr-threads/compare/v2.0.3...v2.0.4). Raw API responses, tag refs and delta evidence are retained.

## Replacement validation and diagnostic gate

REPLACEMENT_COMMAND_TABLE

REPLACEMENT_RESULTS

The consumed adapter and reconnect tests, all consumers, private isolation, private plugin and actual-daemon matrix now cover exact v2.0.4. The broad default/no-default/test-support results listed later ran against v2.0.3 and remain explicitly historical; they were not repeated or relabeled for a driver/fixture and dependency patch with unchanged consumed public API. The only fixture change captures plugin startup/action streams; that path is covered in all five runtime rows. No support module or graph production feature was changed.

The gate checks `herdr.log`, graph `.graph-local/daemon.log` (including the private plugin daemon), private plugin startup/action stdout and stderr, and threads current/rotated daemon and startup-attempt logs. Threads paths include direct state, the default HOME state and `saved-old-node` preserved by recovery. Root ownership and every path component are checked without following symlinks. Required inventory/read/preservation failures and Rust panic diagnostics fail the suite and retain roots. Graph content, Git objects, native transcripts and plugin package files are excluded from diagnostic scanning. Exact inspected bytes, hashes, sizes, optional absences and exclusions survive successful cleanup under each suite's diagnostics archive.

Routing audit: Herdr and graph daemon stdout/stderr go to their file logs. Elected threads runtime redirects both streams to `daemon.log` with one rotated predecessor; pre-election diagnostics/panics go through stderr to startup-attempt logs. Upstream pre-election stdout is `/dev/null`; the inspected pre-election path reports errors on stderr and has no stdout diagnostic producer. Private plugin commands are captured internally by Herdr, so the fixture now preserves both completed stdout/stderr streams through its public log API into `plugin-diagnostics.log`. Process-inspection utility stderr is not a daemon diagnostic source; cleanup failures still fail qualification.

The regression first failed on the original actual `run_suite`: harness success and clean cleanup still yielded PASS for a child-log-only panic. After the fix it yields FAIL, retains the root and archives the diagnostic. Tests additionally cover successful archival/removal, missing and unreadable required logs, file/ancestor symlink refusal, threads startup/rotation/saved-node diagnostics, required suite destinations, private plugin missing/panic output, and exclusion of graph transcript content. All prior inventory/timeout/isolation/ownership/cleanup tests remain active.

## Replacement evidence and preservation

The retained root is `/private/tmp/hg-final-log-qualification-htb_4uwf`, with an independent frozen `graph` clone, initialized official submodule, independent build cache, copied official Herdr binaries and raw final/failed logs. [The replacement bundle](../validation/2026-10-18-threads2-log-qualification/README.md) contains every case, cleanup and diagnostic inspection result, raw diagnostic bytes, command outcomes, source hashes, tag/API provenance and preservation checks. The child-log-only failure reproduction retains `/private/tmp/hg-97ad75d3b9894e53941c50cb76e91140` and `failure-regression/` under the qualification root. Red/sandbox/setup attempts remain their actual outcomes.

The original Task 4 bundle and clone at `/private/tmp/hg-task4-qualification-534cd4f_` are retained unchanged. Source `bin/herdr-graph` remains SHA-256 `bbc9a7bf8de817cb3dcccfae2e5300de5cb7daac8700b40622ddc64c5971621c`, 13,624,672 bytes, with unchanged modification time. The external threads checkout remains clean at its preflight `b83d032a64cb9f665f49806b744f7cc730626819`; this wave only reads it. Frozen source hashes and final preservation assertions document these boundaries.

''' + s[b:]
s=s.replace('## Immutable source and official provenance','## Historical Task 4 source and official provenance')
s=s.replace('## Sequential validation','## Historical Task 4 sequential validation (threads 2.0.3)')
s=s.replace('## Five-version runtime matrix','## Historical Task 4 matrix (harness-only panic gate)')
s=s.replace('## Evidence and preserved artifacts','## Historical Task 4 evidence and preserved artifacts')
s=s.replace('no Rust panic diagnostics, no timeouts/cancellations','no Rust panic diagnostics in retained harness output, no timeouts/cancellations')
s=s.replace('Logs retain exact per-case observations, runner PID/PGID, ownership/start identities and cleanup results.', 'Logs retain exact per-case observations, runner PID/PGID, ownership/start identities and cleanup results. Private daemon logs were not inspected or retained before root removal, so this original evidence cannot establish their absence of panics. The replacement qualification above supplies that stronger gate.')
s += '\nRuling: Adopt verified official threads v2.0.4 at b83d032a64cb9f665f49806b744f7cc730626819 for replacement qualification — it became latest stable during the run and exact public service/protocol/node API comparison is unchanged — source pin/lock and actual-daemon evidence must move together; v2.0.3 feature results remain explicitly historical, and later releases need renewed qualification.\n'
p.write_text(s)
p=repo/'docs/verification-matrix.md';s=p.read_text().replace('## Threads 2.0.3 qualification (2026-10-17)','## Historical threads 2.0.3 qualification (2026-10-17)');s=s.replace('Current source qualification uses graph `d9a505','Historical Task 4 qualification used graph `d9a505');a=s.index('## Historical threads')
s=s[:a]+'''## Replacement threads 2.0.4 qualification (2026-10-18)

Frozen graph `e621b44` uses official threads v2.0.4 `b83d032a64cb9f665f49806b744f7cc730626819`, protocol 9, macOS aarch64. The replacement matrix adds post-cleanup inspection and retention of Herdr, graph, threads and private plugin diagnostic logs. The earlier matrix below checked only harness output for panics and removed daemon logs; it cannot establish absence of private-daemon panics.

REPLACEMENT_RESULTS

Focused v2.0.4 validation and exact source/command/count details are recorded in [the current handoff](releases/2026-10-17-threads2-herdr-qualification.md) and [replacement evidence](validation/2026-10-18-threads2-log-qualification/README.md). All-consumer, adapter/reconnect, isolation and driver checks cover the latest exact dependency. Broad Rust feature suites below remain evidence for their recorded v2.0.3 source; no result is relabeled. Native, remote and live-session exclusions remain unchanged.

''' +s[a:];p.write_text(s)
