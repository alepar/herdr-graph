import subprocess, os, json, time, hashlib, datetime
from pathlib import Path
root=Path(__file__).parent; graph=root/'graph'
env={k:v for k,v in os.environ.items() if not k.startswith(('ANTHROPIC_','OPENAI_','HERDR_','CLAUDE_','HT_','HG_'))}
env['HG_REAL_AGENTS']='0';env['PYTHONDONTWRITEBYTECODE']='1'
env['HG_TEST_HERDR_BINARY']=str(root/'herdr-cache/0.9.5/macos-aarch64/herdr')
head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=graph,text=True).strip()
def snapshot(repo):
 out={}
 for record in subprocess.check_output(['git','ls-files','--stage','-z'],cwd=repo).decode().split('\0'):
  if not record:continue
  meta,path=record.split('\t');mode,obj,stage=meta.split()
  p=repo/path
  out[path]={'mode':mode,'git':obj,'sha256':hashlib.sha256(p.read_bytes()).hexdigest() if mode!='160000' else None}
 return out
source={'head':head,'graph':snapshot(graph),'threads_head':subprocess.check_output(['git','rev-parse','HEAD'],cwd=graph/'third_party/herdr-threads',text=True).strip(),'threads':snapshot(graph/'third_party/herdr-threads')}
(root/'frozen-source.json').write_text(json.dumps(source,indent=2)+'\n')
commands=[
('all-consumers',['cargo','check','--locked','--offline','--all-targets','--all-features']),
('isolation',['cargo','test','--locked','--offline','--features','private-herdr','--test','test_isolation','--','--test-threads=1','--nocapture']),
('driver',['python3','-m','unittest','discover','-s','scripts/tests','-v']),
('matrix',['scripts/herdr-release-smoke','--versions','0.9.1','0.9.2','0.9.3','0.9.4','0.9.5','--jobs','2','--cache',str(root/'herdr-cache'),'--report',str(root/'matrix')]),
]
results=[]
for name,command in commands:
 start=time.monotonic(); log=root/'logs'/f'{name}.log'; print('START',name,flush=True)
 with log.open('w') as out: r=subprocess.run(command,cwd=graph,env=env,stdout=out,stderr=subprocess.STDOUT)
 result={'name':name,'command':command,'cwd':str(graph),'head':head,'threads_head':source['threads_head'],'exit_code':r.returncode,'seconds':round(time.monotonic()-start,3),'log':str(log)}
 results.append(result);(root/'command-results.json').write_text(json.dumps(results,indent=2)+'\n')
 print('END',name,result['exit_code'],result['seconds'],flush=True)
 if r.returncode:raise SystemExit(r.returncode)
assert source['graph']==snapshot(graph)
assert source['threads']==snapshot(graph/'third_party/herdr-threads')
print('FROZEN SOURCE UNCHANGED',flush=True)
