from pathlib import Path
import json,re,hashlib,subprocess
root=Path(__file__).parent;base=root.parent;repo=Path('/Users/alepar/AleCode/herdr-graph');bundle=repo/'docs/validation/2026-10-18-threads2-log-qualification'
v=json.loads((root/'verified-evidence.json').read_text());commands=json.loads((root/'command-results.json').read_text());earlier=[c for c in json.loads((base/'command-results.json').read_text()) if c['name'] in ('adapter','reconnect')];commands=earlier+commands
head=v['source_head'];fix=subprocess.check_output(['git','rev-parse','249067b'],cwd=repo,text=True).strip()
results=f"All five Herdr releases **0.9.1–0.9.5 passed 37/37 cases each** (30 graph + 5 API + 2 actual threads): **185 total**. All **15 cleanup gates and 15 diagnostic gates passed**, with **190 owned roots removed**, zero emergency reaping/survivors, and **{v['diagnostic_files']} raw diagnostic files ({v['diagnostic_bytes']:,} bytes)** retained. Actual binary versions and SHA-256 values matched the official pins. There were no skipped/ignored/filtered matrix cases, Rust panic diagnostics in the inspected streams, timeouts or cancellations."
counts={'all-consumers':'all targets/features compiled','adapter':'56 passed, 0 failed','reconnect':'18 passed, 0 failed (8 harness threads)','isolation':'13 passed, 0 failed/ignored/filtered','driver':'35 passed, 0 failures/errors/skips','matrix':'185 passed; 15 cleanup + 15 log gates clean'}
lines=['| Exact command | Source / dependency | Result | Exit | Seconds |','|---|---|---|---:|---:|']
for c in commands:
 command=' '.join(c['command'])
 lines.append(f"| `{command}` | `{c['head'][:8]}` / `b83d032a` | {counts[c['name']]} | {c['exit_code']} | {c['seconds']} |")
table='\n'.join(lines)
for name in ['docs/releases/2026-10-17-threads2-herdr-qualification.md','docs/validation/herdr-release-matrix.md','docs/verification-matrix.md']:
 p=repo/name;s=p.read_text().replace('REPLACEMENT_RESULTS',results).replace('REPLACEMENT_COMMAND_TABLE',table).replace('frozen graph `e621b44`',f'frozen graph `{head}`').replace('Frozen graph `e621b44`',f'Frozen graph `{head}`');p.write_text(s)
readme=f'''# Retained private diagnostics qualification — 2026-10-18

Frozen graph `{head}`, official threads v2.0.4 `{v['threads_head']}`, protocol 9, macOS aarch64. {results}

- [Matrix JSON](matrix.json) and [Markdown](matrix.md): all exact case, cleanup, diagnostic gate and root/PID results. Original absolute paths point into the retained root below; the raw archive mirrors their relative paths.
- [Verified evidence](verified-evidence.json): actual Herdr/threads versions and binary hashes, raw-log totals, all suite results, {v['source_inputs_equal']} executable-input equivalence checks, and source binary/external checkout/historical evidence preservation assertions.
- [Sequential commands](command-results.json): all-consumer/isolation 13/driver 35/full 185-case matrix at the final frozen source. Adapter56 and reconnect 18 passed at `e621b440` with the same v2.0.4 dependency before the fixture-only amendment; see [first-attempt commands](first-attempt-command-results.json). No broad feature suite is relabeled from older 2.0.3 evidence.
- [Official release metadata](official-provenance.json), [exact 2.0.4 tag refs](threads-v2.0.4-tag-refs.txt), [consumed API comparison](consumed-api-delta.json), [tested pins](herdr-releases-tested.tsv). Full official API responses and compare patches remain in the archive. Herdr `--check-upstream` passed for all five releases and 20 assets. Final official latest metadata at 2026-10-18T07:34:08Z still reports threads v2.0.4 and Herdr v0.9.5; the raw final responses are under `replacement/` in the archive.
- [Preflight artifact state](preflight.json), [review copy checksum](final-review-copy.json), [all eight controller rulings](controller-rulings.txt).
- [Raw evidence archive](raw-evidence.tar.gz) and [member hashes/lengths](raw-evidence-manifest.json): full harness/build/check logs, roots and cleanup records, every inspected diagnostic's exact bytes, explicit optional absences/exclusions, frozen graph/submodule input hashes, scripts used for this qualification, and red/failure evidence. Every member was reopened and matched against its original bytes.

The independent final clone is `/private/tmp/hg-final-log-qualification-htb_4uwf/replacement/graph`. Graph and submodule remain detached and clean. The parent directory preserves the first failed freeze at `e621b440` and its 35 failed-suite roots. [Failure diagnosis](failure-diagnosis.json) records the archived-path publication race, updater curl leak, exact process identities, and fixture-only fixes. The retained actual-driver panic reproduction has successful harness output and clean cleanup but FAIL status; its root `/private/tmp/hg-97ad75d3b9894e53941c50cb76e91140` remains, and its complete diagnostics/results are under `failure-regression/` in the archive. Original red tests failed with 8 failures and one missing-archive error; the later private-plugin red had 2 failures; green 33 and first frozen 33 passed. Added internal Herdr current/rotated-log cases then reproduced five false-PASS failures at 35 tests; final 35 passed. The actual-server updater regression failed with default config, passed after disabling supported update checks, and isolation 13 plus focused resurrection passed before freezing. The red updater root was removed by normal fixture Drop; its printed diagnostics and exact post-run PID/PPID/PGID/root absence check are retained with that limit stated. The first sandboxed attempt could not run macOS process inspection and is retained as an environment/setup failure, not regression proof.

Diagnostic scope includes required Herdr stdout/stderr and internal server tracing, optional known main/client tracing and numeric rotations, graph (including private plugin daemon), plugin startup/action streams, and threads daemon/rotated/startup logs in the three exercised node destinations. Symlinks are refused at every path component. Graph content, Git objects, native transcripts and plugin package files are excluded. Existing threads nodes require daemon and startup logs; graph suites require all graph logs and one plugin capture. Successful cleanup happens only after raw diagnostic preservation. Required inspection/preservation errors or panic diagnostics retain roots and fail qualification.

The old [Task 4 bundle](../2026-10-17-threads2-qualification/README.md) and `/private/tmp/hg-task4-qualification-534cd4f_` are unchanged historical evidence. That run checked harness output for panics and removed uninspected private-daemon logs; it cannot establish their absence of panics. Its broad Rust feature results remain specific to recorded 2.0.3 source. The current replacement supersedes the runtime qualification claim.

Native agents/inference/auth/bootstrap/root-agent/summarizer execution, remote continuity, actual restore holds, Linux/Intel runtime and live-session handoff remain excluded. No live service was restarted, no source plugin binary installed, no external checkout edited, no graph version bumped, and no merge/push/publication occurred. The [handoff](../../releases/2026-10-17-threads2-herdr-qualification.md) records migration limits and controller review gates.

Verify this bundle from its directory with `shasum -a 256 -c SHA256SUMS`. Archive members are relative paths; extract only into a fresh empty private directory.
'''
(bundle/'README.md').write_text(readme)
report=f'''# Combined final-review fix implementation — 2026-10-18

Status: I1 and M1 addressed; replacement qualification passes. Scoped independent rereview and integration remain controller work. Base `fcad880`; branch `threads2-herdr-matrix`.

## Findings and exact commits

- I1: commit `{fix}` adds post-cleanup inspection of actual owned Herdr, graph, threads and private plugin diagnostic destinations. Every component is opened relative to an owned root with symlink refusal; exact raw bytes, SHA-256, size and inspection outcomes are preserved before success removal. Required log/inventory/read/preservation errors and Rust panics fail and retain roots. Existing exact case/root, timeout, forbidden-tool, isolation and cleanup gates remain active. Private plugin startup/action stdout/stderr is retained through Herdr's public log API; the detached plugin graph daemon already uses the graph log.
- Controller-approved latest-release update: commit `e621b44010298ffe879c51f83601ed95563ac88d` changes only the graph-owned gitlink to official v2.0.4 `{v['threads_head']}` and the graph lockfile package version 2.0.3→2.0.4. Official annotated tag `b869ebe878e1b947c1fb7fad054755dca0950f51` peels to this SHA. Metadata at 2026-10-18T07:00:36Z found v2.0.4 newly published at 06:56:10Z. Exact protocol/service/node/path/discovery diffs from v2.0.3 are empty; wire remains 9. The external checkout was read-only throughout.
- Follow-up fixture/driver amendment `{head}` adds required internal Herdr tracing and optional known numeric rotations, disables private background version/manifest checks using settings supported by all five pinned releases, and waits for archived worktree materialization within the existing `WAIT`. All original identity/state/resurrection assertions and strict emergency-reap-fails gates remain. No production writer edit.
- M1: current matrix prerequisites now use `git submodule update --init --recursive`, an exact official gitlink and both locked Cargo cache prerequisites. The controller's later 2.0.4 ruling supersedes the brief's initial 2.0.3 target; docs explicitly preserve that transition. No dated Task3 report or original Task4 bundle changed. README/current design/current plan/matrix/handoff now identify 2.0.4 and distinguish historical 2.0.3 results.
- The docs/evidence commit contains this report and the byte-identical independent final review at `docs/superpowers/reviews/2026-10-17-threads2-final-review.md`; its hash is in `final-review-copy.json`. All seven original Ruling lines are byte-identical, with the approved eighth appended.

## Red-green and diagnosis

Root cause: actual `run_suite` passed only harness output into classification, then removed owned roots after clean process teardown. Herdr wrote `herdr.log`; detached graph wrote `graph/.graph-local/daemon.log`; threads wrote node daemon/rotation/startup logs, including a saved old node during recovery. Herdr captured plugin command output internally. These were absent from the original gate/evidence.

Actual-driver tests were written first. `python3 -m unittest discover -s scripts/tests -v` against the original driver ran 31 tests and failed with 8 failures plus 1 missing-archive error, including the successful-harness/clean-teardown child-log panic false-PASS. Original red output beneath the parent evidence root is `logs/hg-final-fix-red-unsandboxed.log`. The initial sandboxed run failed macOS `/bin/ps` access and remains `logs/hg-final-fix-red.log` as a setup failure. After the initial log gate, 31 tests passed. Added private plugin missing/panic cases then failed twice at 33 tests (`logs/hg-final-fix-plugin-red.log`). With the complete gate and capture, 33 passed (`logs/hg-final-fix-green-final.log`); first frozen 33 passed again. The stronger internal-log regression ran 35 tests against that driver and produced five expected failures; final 35 passed (`logs/internal-log-red.log`, `logs/internal-log-green.log`). Those logs are under the parent evidence root.

Behavioral coverage includes panic only in a daemon log, successful raw preservation before root removal, missing/unreadable required logs, file and ancestor symlink refusal without external-data capture, required graph/threads/plugin inventories, saved/rotated/startup threads logs, private plugin streams and exclusion of graph transcript content. Prior timeout, signal, exact inventory, ownership, forbidden tools and cleanup cases remain. The retained actual-driver failure reproduction preserves `{base}/failure-regression` and root `/private/tmp/hg-97ad75d3b9894e53941c50cb76e91140`: zero-exit successful case, clean teardown, diagnostic FAIL, raw panic preserved.

## First replacement failure and minimal fixture fixes

The first frozen attempt at `e621b44010298ffe879c51f83601ed95563ac88d` completed all-consumer, adapter 56, reconnect 18, isolation 12 and driver 33 checks, then its matrix exited 1. Herdr 0.9.1–0.9.4 each passed 37 cases under the earlier diagnostic inventory. Herdr 0.9.5 E2E passed 29/30; API passed 5/5 but failed cleanup; threads passed 2/2. This result remains FAIL with all raw logs and 35 failed-suite roots retained.

The resurrection assertion saw a retired Git row and settled effects before `writer.finish_commit` completed worktree fast-forward. HEAD/index/view_rev evidence proves the ordering: CAS publication and journal completion precede worktree materialization. Teardown after the assertion interrupted that work. The fixture now waits, within unchanged WAIT, for the archived path before retaining its original assertion. Focused actual Herdr 0.9.5 resurrection passed 1/0 (29 unrelated cases filtered) before freezing; every version reruns the unchanged scenario assertions.

The API fixture's default background updater spawned curl PID 99371 in server PGID 99276. It outlived the parent; the driver retained its proven identity and emergency-reaped it, correctly failing qualification. Exact pinned config/App source proves both public update flags are supported across 0.9.1–0.9.5. The new actual-server regression failed with the empty config, then passed with both disabled. Isolation13 passed. The red run's own servers 3246/3314/root were checked after completion: no PID/PPID/PGID/root matches, no signals sent. That root had been removed by normal Drop; its printed logs and explicit absence-check limitation remain in `updater-red-quiescence.json`.

The investigation also identified Herdr's separate internal tracing directory. Required server tracing plus known main/client/current/numeric-rotation files are now inventoried using the same no-symlink root access. Standard panic-only internal logs and a missing server log reproduced five expected false-PASS failures before the fix. Exact server bootstrap/logging code installs tracing only; the client panic hook restores terminal state then calls original_hook(info), retaining standard stderr panic format. Herdr defaults to 5 MiB per tracing file with zero retained rotations; present numeric rotations are inspected. Post-failure bounded capture recovered 101 files from the 35 retained roots without changing the failed result.

Parent-root `failure-diagnosis.json`, `failed-archive-state/`, `herdr-routing-source/`, `post-failure-diagnostics/`, `amendment-checks.json`, and red/green logs preserve the rationale. No tolerance, timeout widening, assertion deletion, production behavior change, or emergency-cleanup relabeling was used.

## Frozen verification

Independent source clone `{root}/graph` was detached at `{head}` before runtime; exact submodule `{v['threads_head']}`. All tracked graph/submodule inputs were hashed before and after; {v['source_inputs_equal']} executable inputs also match the final shared tree. Build-cache copies have independent file identities; old source/evidence is untouched. Cargo stages were sequential; workers reused completed executables. Pre-freeze e2e fixture compilation and all-consumer check also passed, with raw logs retained; canonical frozen evidence follows.

{table}

{results}

Adapter/reconnect results are retained at e621b440 with the same exact threads 2.0.4 dependency; final all-consumer/isolation/driver/matrix results are at the amended freeze. The adapter group used the `threads::` filter (592 unrelated cases filtered); reconnect used `reconnect` with 8 threads (630 unrelated cases filtered). Matrix inventories have zero filtered/ignored/skipped cases. The plugin capture is exercised by its actual E2E case on all 5 releases; isolation 13 verifies process teardown, disabled private updater behavior and fixture source safety. The support module change is private fixture configuration only; graph production source is unchanged. The latest dependency changes native child lifecycle identity internals; consumed public contracts are unchanged, and native child/bootstrap/inference behavior is not claimed as tested by this shell/synthetic matrix.

Broad default/no-default/test-support suites were not repeated: their historical 2.0.3 results remain at their original source heads, not relabeled as 2.0.4 passes. The latest target is covered by all consumers, focused adapter/reconnect, isolation, driver and full actual-daemon matrix. This follows the explicit controller ruling.

## Evidence, preservation and limits

Permanent bundle: `docs/validation/2026-10-18-threads2-log-qualification/`; retained root: `{root}`. Includes all exact case/cleanup/diagnostic outcomes, actual versions/checksums, full inspected raw logs, exclusions, all command exits/durations/heads, source hashes, original red/plugin-red/setup logs, official metadata/tag/API delta, and independent-review/rulings checks. The archive was reopened and all member lengths/hashes verified; bundle SHA256SUMS cover all files.

Original Task4 bundle and clone remain unchanged. Original root plugin binary remains `{v['artifact_preserved']['sha256']}`, {v['artifact_preserved']['bytes']} bytes, mtime_ns {v['artifact_preserved']['mtime_ns']}. External checkout remains clean at preflight `{v['external_checkout_head']}`; no edits were made there. No live Herdr/threads/session/check-in/membership actions, model credentials/native agents, live install/restart, main/remote-branch mutation, merge/push/release/graph-version bump occurred.

Unchanged exclusions: native launch/resume/SessionStart bootstrap/root-agent/summarizer inference/auth, real remote continuity, actual restore-induced holds, Linux/Intel runtime and live handoff. The original 2.0.3 daemon logs were removed before this fix and cannot be reconstructed; they remain explicitly narrower historical evidence. Stronger replacement evidence supports the new runtime claim. Scoped final rereview remains pending with the controller.
'''
workspace=repo/'.superpowers/sdd/2026-10-17-threads2-herdr-matrix/final-fix-report.md'
workspace.write_text(report)
(repo/'docs/superpowers/reviews/2026-10-17-threads2-final-fix-implementation.md').write_text(report)
# Checksums include README; the sums file excludes itself.
(bundle/'SHA256SUMS').write_text(''.join(f'{hashlib.sha256(p.read_bytes()).hexdigest()}  {p.name}\n' for p in sorted(bundle.iterdir()) if p.is_file() and p.name!='SHA256SUMS'))
print('Finalized docs and report',head)
