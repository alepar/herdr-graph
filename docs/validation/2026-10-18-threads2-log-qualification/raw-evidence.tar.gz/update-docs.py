from pathlib import Path
repo=Path('/Users/alepar/AleCode/herdr-graph')
old='ded34fa971c18cef81ea1b597097a8ff7cd91eb3';new='b83d032a64cb9f665f49806b744f7cc730626819'
for name in ['README.md','CURRENT-DESIGN.md']:
 p=repo/name;s=p.read_text().replace('2.0.3','2.0.4').replace(old,new)
 if name=='README.md':
  s=s.replace('October 17 exact threads 2.0.4 qualification','October 18 replacement threads 2.0.4 qualification')
  s=s.replace('(185 total), with clean teardown.', '(185 total), with clean teardown and retained private-daemon/plugin diagnostics.')
 p.write_text(s)
p=repo/'docs/superpowers/plans/2026-10-17-threads2-herdr-matrix.md';s=p.read_text().replace('Target official herdr-threads v2.0.3 commit '+old,'Target official herdr-threads v2.0.4 commit '+new);s=s.replace('External checkout is read-only.','External checkout is read-only. The official 2.0.4 tag was reverified on October 18 after publication during qualification; consumed public service/protocol/node APIs are unchanged from 2.0.3.');p.write_text(s)
p=repo/'docs/validation/herdr-release-matrix.md';s=p.read_text();a=s.index('Use the ordinary Rust toolchain');b=s.index('## Runtime coverage',a)
s=s[:a]+'''Use the ordinary Rust toolchain and the repository lockfiles. The dependency is
an official Git submodule, currently pinned to herdr-threads **v2.0.4**, exact
commit `b83d032a64cb9f665f49806b744f7cc730626819`, wire protocol **9**.
It supersedes the earlier official v2.0.3 pin `ded34fa971c18cef81ea1b597097a8ff7cd91eb3`:
v2.0.4 became latest stable during replacement qualification, and its tag and
unchanged consumed public API were reverified before updating the gitlink/lock.

```sh
git submodule update --init --recursive
git -C third_party/herdr-threads rev-parse HEAD
cargo fetch --locked
cargo fetch --locked --manifest-path third_party/herdr-threads/Cargo.toml
```

The reported submodule HEAD must equal the exact official commit above. Populate
both locked dependency caches before running the sweep; all sweep builds use
`--locked --offline`. In a prepopulated environment no fetch is needed. A fresh
clone can use `git clone --recurse-submodules <graph-repository-url>`. Source
archives must explicitly include the pinned submodule contents. This setup never
requires editing a separate external threads checkout. The old absolute-symlink
and post-tag account remains only in the dated Task 3 report.

''' + s[b:]
a=s.index('qualification fail. Successful runs');b=s.index('SIGKILL of the driver',a)
s=s[:a]+'''qualification fail. After process cleanup, the driver inspects known owned
runtime destinations and retains exact raw bytes, lengths and SHA-256 values in
`diagnostics/` plus `diagnostics.json`. It requires `herdr.log` in every root,
`graph/.graph-local/daemon.log` in every graph E2E root, one private plugin's
captured startup/action stdout and stderr (`plugin-diagnostics.log`) per graph
suite, and all three threads nodes exercised by the threads suite. Threads
inspection includes `daemon.log`, optional `daemon.log.1`, and the existing
`logs/startup-<pid>-<nonce>.log` files in the direct state node, default HOME node,
and preserved `saved-old-node`. Existing nodes require a daemon log and startup
log. The plugin daemon itself uses the graph daemon log.

Every path component is opened relative to the owned root with symlink refusal;
only those destinations are inspected, with no recursive content/Git/transcript
scan. Missing/unreadable required logs, inventory failures, preservation errors,
or Rust panic diagnostics make qualification fail and retain roots. Optional
absences and deliberate content exclusions are recorded. Successful runs remove
only their token-verified fixture roots after raw diagnostics have been preserved.
Failure roots, logs, and PID evidence remain for inspection. An external
''' + s[b:]
a=s.index('## Qualification status —')
s=s[:a]+'''## Replacement qualification — 2026-10-18

The stronger replacement matrix uses frozen graph `e621b44` and official threads
v2.0.4 `b83d032a64cb9f665f49806b744f7cc730626819`, protocol 9, on macOS aarch64.
REPLACEMENT_RESULTS

[The integration handoff](../releases/2026-10-17-threads2-herdr-qualification.md)
records exact source, commands, native exclusions, migration limits and rulings.
[The replacement evidence bundle](2026-10-18-threads2-log-qualification/README.md)
retains raw inspected diagnostics as well as every case/cleanup/log gate result.
Runtime support is limited to this tested macOS architecture; Linux/Intel digests
alone do not imply qualification. Scoped final rereview/integration remain
controller gates; this is not a merge or publication claim.

## Historical qualification and its limit — 2026-10-17

At graph `d9a50590c6ca3dccc558664d4ed608eb2153605d` with official threads v2.0.3
`ded34fa971c18cef81ea1b597097a8ff7cd91eb3`, all five releases produced 37 successful
case results each (185 total), exact inventories and 15 clean cleanup records.
The earlier panic gate inspected harness output only. Private daemon logs were
removed with the 190 roots, so that evidence cannot establish absence of daemon
panics. The original [Task 4 bundle](2026-10-17-threads2-qualification/README.md)
and retained clone remain unchanged historical evidence; the stronger result
above replaces the runtime qualification claim.

Historical Task 3 evidence qualified only 0.9.5 against the clean post-tag
external checkout. Its failed/cancelled trials and
[implementation report](../superpowers/reviews/2026-10-17-threads2-task-3-implementation.md)
remain preserved.
'''
p.write_text(s)
