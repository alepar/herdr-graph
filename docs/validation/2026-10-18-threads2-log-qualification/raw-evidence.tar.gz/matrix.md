Herdr graph release matrix at e621b44010298ffe879c51f83601ed95563ac88d (herdr-macos-aarch64)

Private shell and synthetic-hook qualification; no native model launches.

| Herdr | Result | graph E2E (30) | Herdr API (5) | actual threads (2) |
| --- | --- | --- | --- | --- |
| 0.9.1 | PASS | PASS | PASS | PASS |
| 0.9.2 | PASS | PASS | PASS | PASS |
| 0.9.3 | PASS | PASS | PASS | PASS |
| 0.9.4 | PASS | PASS | PASS | PASS |
| 0.9.5 | FAIL | FAIL | FAIL | PASS |

Aggregate result: FAIL.

Logs: /private/tmp/hg-final-log-qualification-htb_4uwf/matrix.logs
