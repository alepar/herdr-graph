from pathlib import Path
import json,re,hashlib,subprocess
root=Path(__file__).parent;repo=Path('/Users/alepar/AleCode/herdr-graph');bundle=repo/'docs/validation/2026-10-18-threads2-log-qualification'
v=json.loads((root/'verified-evidence.json').read_text());commands=json.loads((root/'command-results.json').read_text())
head=v['source_head'];fix=subprocess.check_output(['git','rev-parse','249067b'],cwd=repo,text=True).strip()
results=f"All five Herdr releases **0.9.1–0.9.5 passed 37/37 cases each** (30 graph + 5 API + 2 actual threads): **185 total**. All **15 cleanup gates and 15 diagnostic gates passed**, with **190 owned roots removed**, zero emergency reaping/survivors, and **{v['diagnostic_files']} raw diagnostic files ({v['diagnostic_bytes']:,} bytes)** retained. Actual binary versions and SHA-256 values matched the official pins. There were no skipped/ignored/filtered matrix cases, Rust panic diagnostics in the inspected streams, timeouts or cancellations."
counts={'all-consumers':'all targets/features compiled','adapter':'56 passed, 0 failed','reconnect':'18 passed, 0 failed (8 harness threads)','isolation':'12 passed, 0 failed/ignored/filtered','driver':'33 passed, 0 failures/errors/skips','matrix':'185 passed; 15 cleanup + 15 log gates clean'}
lines=['| Exact command | Source / dependency | Result | Exit | Seconds |','|---|---|---|---:|---:|']
for c in commands:
 command=' '.join(c['command'])
 lines.append(f"| `{command}` | `{head[:8]}` / `b83d032a` | {counts[c['name']]} | {c['exit_code']} | {c['seconds']} |")
table='\n'.join(lines)
for name in ['docs/releases/2026-10-17-threads2-herdr-qualification.md','docs/validation/herdr-release-matrix.md','docs/verification-matrix.md']:
 p=repo/name;s=p.read_text().replace('REPLACEMENT_RESULTS',results).replace('REPLACEMENT_COMMAND_TABLE',table).replace('`e621b44`',f'`{head}`');p.write_text(s)
readme=f'''# Retained private diagnostics qualification — 2026-10-18

Frozen graph `{head}`, official threads v2.0.4 `{v['threads_head']}`, protocol 9, macOS aarch64. {results}

- [Matrix JSON](matrix.json) and [Markdown](matrix.md): all exact case, cleanup, diagnostic gate and root/PID results. Original absolute paths point into the retained root below; the raw archive mirrors their relative paths.
- [Verified evidence](verified-evidence.json): actual Herdr/threads versions and binary hashes, raw-log totals, all suite results, {v['source_inputs_equal']} executable-input equivalence checks, and source binary/external checkout/historical evidence preservation assertions.
- [Sequential commands](command-results.json): all-consumer check, adapter56, reconnect18, isolation12, driver33 and full185-case matrix, all exit0 on the exact frozen source. No broad feature suite is relabeled from older 2.0.3 evidence.
- [Official release metadata](official-provenance.json), [exact 2.0.4 tag refs](threads-v2.0.4-tag-refs.txt), [consumed API comparison](consumed-api-delta.json), [tested pins](herdr-releases-tested.tsv). Full official API responses and compare patches remain in the archive. Herdr `--check-upstream` passed for all five releases and 20 assets.
- [Preflight artifact state](preflight.json), [review copy checksum](final-review-copy.json), [all eight controller rulings](controller-rulings.txt).
- [Raw evidence archive](raw-evidence.tar.gz) and [member hashes/lengths](raw-evidence-manifest.json): full harness/build/check logs, roots and cleanup records, every inspected diagnostic's exact bytes, explicit optional absences/exclusions, frozen graph/submodule input hashes, scripts used for this qualification, and red/failure evidence. Every member was reopened and matched against its original bytes.

The independent retained root is `/private/tmp/hg-final-log-qualification-htb_4uwf`. Graph and submodule remain detached and clean. The retained actual-driver panic reproduction has successful harness output and clean cleanup but FAIL status; its root `/private/tmp/hg-97ad75d3b9894e53941c50cb76e91140` remains, and its complete diagnostics/results are under `failure-regression/` in the archive. Original red tests failed with 8 failures and one missing-archive error; the later private-plugin red had 2 failures; green33 and frozen33 passed. The first sandboxed attempt could not run macOS process inspection and is retained as an environment/setup failure, not regression proof.

Diagnostic scope is bounded to Herdr, graph (including private plugin daemon), plugin startup/action streams, and threads daemon/rotated/startup logs in the three exercised node destinations. Symlinks are refused at every path component. Graph content, Git objects, native transcripts and plugin package files are excluded. Existing threads nodes require daemon and startup logs; graph suites require all graph logs and one plugin capture. Successful cleanup happens only after raw diagnostic preservation. Required inspection/preservation errors or panic diagnostics retain roots and fail qualification.

The old [Task 4 bundle](../2026-10-17-threads2-qualification/README.md) and `/private/tmp/hg-task4-qualification-534cd4f_` are unchanged historical evidence. That run checked harness output for panics and removed uninspected private-daemon logs; it cannot establish their absence of panics. Its broad Rust feature results remain specific to recorded 2.0.3 source. The current replacement supersedes the runtime qualification claim.

Native agents/inference/auth/bootstrap/root-agent/summarizer execution, remote continuity, actual restore holds, Linux/Intel runtime and live-session handoff remain excluded. No live service was restarted, no source plugin binary installed, no external checkout edited, no graph version bumped, and no merge/push/publication occurred. The [handoff](../../releases/2026-10-17-threads2-herdr-qualification.md) records migration limits and controller review gates.

Verify this bundle from its directory with `shasum -a 256 -c SHA256SUMS`. Archive members are relative paths; extract only into a fresh empty private directory.
'''
(bundle/'README.md').write_text(readme)
report=f'''# Combined final-review fix implementation — 2026-10-18

Status: I1 and M1 addressed; replacement qualification passes. Scoped independent rereview and integration remain controller work. Base `fcad880`; branch `threads2-herdr-matrix`.

## Findings and exact commits

- I1: commit `{fix}` adds post-cleanup inspection of actual owned Herdr, graph, threads and private plugin diagnostic destinations. Every component is opened relative to an owned root with symlink refusal; exact raw bytes, SHA-256, size and inspection outcomes are preserved before success removal. Required log/inventory/read/preservation errors and Rust panics fail and retain roots. Existing exact case/root, timeout, forbidden-tool, isolation and cleanup gates remain active. The fixture's only Rust change preserves private plugin startup/action stdout/stderr through Herdr's public log API; the detached plugin graph daemon already uses the graph log.
- Controller-approved latest-release update: commit `{head}` changes only the graph-owned gitlink to official v2.0.4 `{v['threads_head']}` and the graph lockfile package version 2.0.3→2.0.4. Official annotated tag `b869ebe878e1b947c1fb7fad054755dca0950f51` peels to this SHA. Metadata at 2026-10-18T07:00:36Z found v2.0.4 newly published at 06:56:10Z. Exact protocol/service/node/path/discovery diffs from v2.0.3 are empty; wire remains9. The external checkout was read-only throughout.
- M1: current matrix prerequisites now use `git submodule update --init --recursive`, an exact official gitlink and both locked Cargo cache prerequisites. The controller's later 2.0.4 ruling supersedes the brief's initial2.0.3 target; docs explicitly preserve that transition. No dated Task3 report or original Task4 bundle changed. README/current design/current plan/matrix/handoff now identify2.0.4 and distinguish historical2.0.3 results.
- The docs/evidence commit contains this report and the byte-identical independent final review at `docs/superpowers/reviews/2026-10-17-threads2-final-review.md`; its hash is in `final-review-copy.json`. All seven original Ruling lines are byte-identical, with the approved eighth appended.

## Red-green and diagnosis

Root cause: actual `run_suite` passed only harness output into classification, then removed owned roots after clean process teardown. Herdr wrote `herdr.log`; detached graph wrote `graph/.graph-local/daemon.log`; threads wrote node daemon/rotation/startup logs, including a saved old node during recovery. Herdr captured plugin command output internally. These were absent from the original gate/evidence.

Actual-driver tests were written first. `python3 -m unittest discover -s scripts/tests -v` against the original driver ran31 tests and failed with8 failures plus1 missing-archive error, including the successful-harness/clean-teardown child-log panic false-PASS. Original red output is `logs/hg-final-fix-red-unsandboxed.log`. The initial sandboxed run failed macOS `/bin/ps` access and remains `logs/hg-final-fix-red.log` as a setup failure. After the initial log gate,31 tests passed. Added private plugin missing/panic cases then failed twice at33 tests (`logs/hg-final-fix-plugin-red.log`). With the complete gate and capture,33 passed (`logs/hg-final-fix-green-final.log`); frozen33 passed again.

Behavioral coverage includes panic only in a daemon log, successful raw preservation before root removal, missing/unreadable required logs, file and ancestor symlink refusal without external-data capture, required graph/threads/plugin inventories, saved/rotated/startup threads logs, private plugin streams and exclusion of graph transcript content. Prior timeout, signal, exact inventory, ownership, forbidden tools and cleanup cases remain. The retained actual-driver failure reproduction preserves `{root}/failure-regression` and root `/private/tmp/hg-97ad75d3b9894e53941c50cb76e91140`: zero-exit successful case, clean teardown, diagnostic FAIL, raw panic preserved.

## Frozen verification

Independent source clone `{root}/graph` was detached at `{head}` before runtime; exact submodule `{v['threads_head']}`. All tracked graph/submodule inputs were hashed before and after; {v['source_inputs_equal']} executable inputs also match the final shared tree. Build-cache copies have independent file identities; old source/evidence is untouched. Cargo stages were sequential; workers reused completed executables. Pre-freeze e2e fixture compilation and all-consumer check also passed, with raw logs retained; canonical frozen evidence follows.

{table}

{results}

The adapter group used the `threads::` filter (592 unrelated cases filtered); reconnect used `reconnect` with8 threads (630 unrelated cases filtered). Matrix inventories have zero filtered/ignored/skipped cases. The plugin capture is exercised by its actual E2E case on all5 releases; isolation12 verifies process teardown and fixture source safety. No support module or graph production source changed. The latest dependency changes native child lifecycle identity internals; consumed public contracts are unchanged, and native child/bootstrap/inference behavior is not claimed as tested by this shell/synthetic matrix.

Broad default/no-default/test-support suites were not repeated: their historical2.0.3 results remain at their original source heads, not relabeled as2.0.4 passes. The latest target is covered by all consumers, focused adapter/reconnect, isolation, driver and full actual-daemon matrix. This follows the explicit controller ruling.

## Evidence, preservation and limits

Permanent bundle: `docs/validation/2026-10-18-threads2-log-qualification/`; retained root: `{root}`. Includes all exact case/cleanup/diagnostic outcomes, actual versions/checksums, full inspected raw logs, exclusions, all command exits/durations/heads, source hashes, original red/plugin-red/setup logs, official metadata/tag/API delta, and independent-review/rulings checks. The archive was reopened and all member lengths/hashes verified; bundle SHA256SUMS cover all files.

Original Task4 bundle and clone remain unchanged. Original root plugin binary remains `{v['artifact_preserved']['sha256']}`, {v['artifact_preserved']['bytes']} bytes, mtime_ns {v['artifact_preserved']['mtime_ns']}. External checkout remains clean at preflight `{v['threads_head']}`; no edits were made there. No live Herdr/threads/session/check-in/membership actions, model credentials/native agents, install/restart, main/remote-branch mutation, merge/push/release/graph-version bump occurred.

Unchanged exclusions: native launch/resume/SessionStart bootstrap/root-agent/summarizer inference/auth, real remote continuity, actual restore-induced holds, Linux/Intel runtime and live handoff. The original2.0.3 daemon logs were removed before this fix and cannot be reconstructed; they remain explicitly narrower historical evidence. Stronger replacement evidence supports the new runtime claim. Scoped final rereview remains pending with the controller.
'''
workspace=repo/'.superpowers/sdd/2026-10-17-threads2-herdr-matrix/final-fix-report.md'
workspace.write_text(report)
(repo/'docs/superpowers/reviews/2026-10-17-threads2-final-fix-implementation.md').write_text(report)
# Checksums include README; the sums file excludes itself.
(bundle/'SHA256SUMS').write_text(''.join(f'{hashlib.sha256(p.read_bytes()).hexdigest()}  {p.name}\n' for p in sorted(bundle.iterdir()) if p.is_file() and p.name!='SHA256SUMS'))
print('Finalized docs and report',head)
